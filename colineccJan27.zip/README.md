ecc
===

memory ECC for SCMs 
